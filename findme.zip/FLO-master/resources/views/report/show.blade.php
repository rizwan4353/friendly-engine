@extends("user.layout")

@section('content')
    
    <article class="col-10 mx-auto">
        <div class="card card-300 mb-3">
            <section class="card-img">
                <img src="/storage/{{ $report->image }}" class="card-img-top" alt="{{ $report->fullname }}">
            </section>
            <div class="card-body">
                <h2 class="card-title"><b>Missing</b></h2>
                <div class="card-text">
                    <h5>
                       <b> Name: </b>{{ $report->fullname }}
                    </h5>
                    <h5>
                        <b>Age: </b>{{ $report->age }} years
                    </h5>
                    <h5>
                       <b> Gender: </b>{{ $report->gender }}
                    </h5>
                    <h5>
                        <b>Location: </b>{{ $report->place }}
                    </h5>
                    <h5>
                        <b>Type of Report: </b>{{ $report->type }}
                    </h5>
                    <h5>
                    <b>Description:</b>
                    </h5>
                    <p class="text-justify">{{ $report->description }}</p>
                </div>
            </div>
        </div>
    </article>
    
    <article class="col-10 mx-auto">
        <div class="card">
            <div class="card-header"><h4 class="card-title">Reporter's Details </h4></div>
            <div class="card-body">
                
                <p>
                    <b>Name: </b> {{$report->reporter->fullname}}
                </p>
                <p>
                    <b>Contact: </b> {{$report->reporter->contact}}
                </p>
                <p>
                    <b>CNIC: </b> {{$report->reporter->cnic}}
                </p>
                <p>
                    <b>Address: </b> {{$report->reporter->address}}
                </p>
                
            </div>
        
        </div>
    </article>

@endsection