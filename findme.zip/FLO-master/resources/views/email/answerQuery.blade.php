@component('mail::message')
# Your Question
{{ $question  }}

# Answer
{{ $answer }}
<hr>
Thanks for using our website
@endcomponent
