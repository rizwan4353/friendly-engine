@extends("layouts.app")

@section('content')
    
    <div class="col-8 mx-auto text-justify">
        <div class="card">
            <div class="card-header">
                <h3 >About</h3>
            </div>
            <div class="card-body">
                <p >
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae blanditiis doloribus ea illum incidunt
                    maiores
                    molestiae reiciendis. Cum dolores doloribus, error fugiat incidunt laboriosam laborum magni, maiores
                    recusandae
                    rem sunt.<br>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae blanditiis doloribus ea illum incidunt
                    maiores
                    molestiae reiciendis. Cum dolores doloribus, error fugiat incidunt laboriosam laborum magni, maiores
                    recusandae
                    rem sunt.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae blanditiis doloribus ea illum incidunt
                    maiores
                    molestiae reiciendis. Cum dolores doloribus, error fugiat incidunt laboriosam laborum magni, maiores
                    recusandae
                    rem sunt.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae blanditiis doloribus ea illum incidunt
                    maiores
                    molestiae reiciendis. Cum dolores doloribus, error fugiat incidunt laboriosam laborum magni, maiores
                    recusandae
                    rem sunt.
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae blanditiis doloribus ea illum incidunt
                    maiores
                    molestiae reiciendis. Cum dolores doloribus, error fugiat incidunt laboriosam laborum magni, maiores
                    recusandae
                    rem sunt.<br>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Beatae blanditiis doloribus ea illum incidunt
                    maiores
                    molestiae reiciendis. Cum dolores doloribus, error fugiat incidunt laboriosam laborum magni, maiores
                    recusandae
                    rem sunt.
                </p>
            </div>
        </div>
    </div>

@endsection