<footer class="bg-light py-4 mt-4">
    <div class="text-center">&copy; {{ date('Y') }} All rights are reserved.</div>
</footer>

<a id="to-top" style="display: none">
    <i class="fas fa-chevron-circle-up"></i>
</a>