<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="description" content="find your lost ones">
    <meta name="author" content="Muhammad Waqar">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo e(config('app.title', 'FLO') .' | '.  config('app.name')); ?></title>
    
    
    
    <link href="<?php echo e(asset('css/theme.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/datepicker.min.css')); ?>" rel="stylesheet">
    
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset("css/sb-admin.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
</head>

<body id="page-top">

<?php echo $__env->make('user.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<div id="wrapper">
    
    <?php echo $__env->make('user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div id="content-wrapper">
        
        <main class="container">
            
            <?php echo $__env->yieldContent('content'); ?>
        
        </main>
        
        <footer class="text-dark p-4 mt-4 footer bg-light">
            <div class="container my-auto">
                <div class="copyright text-center my-auto">
                    <span>Copyright © <?php echo e(config('app.name')); ?> <?php echo e(date('Y')); ?></span>
                </div>
            </div>
        </footer>
        <a id="to-top" style="display: none">
            <i class="fas fa-chevron-circle-up"></i>
        </a>
    </div>


</div>




<!-- Scroll to Top Button-->
<a id="to-top" style="display: none">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a class="btn btn-primary" href="login.html">Logout</a>
            </div>
        </div>
    </div>
</div>






<script src="<?php echo e(asset("js/jquery-3.3.1.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/bootstrap.bundle.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/sb-admin.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/notify.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/datepicker.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/script.js")); ?>"></script>
<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
