<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="description" content="find your lost ones">
    <meta name="author" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    
    <title><?php echo e(config('app.title', 'FLO') .' | '.  config('app.name')); ?></title>
    
    
    <link href="<?php echo e(asset('css/theme.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet">
    
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
</head>
<body>
<div id="app">
    
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <div id="carouselExampleIndicators" class="carousel slide slider container" data-ride="carousel" data-interval="10000">
        
        <ol class="carousel-indicators">
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-target="#carouselExampleIndicators" data-slide-to="<?php echo e($loop->index); ?>"
                    class="<?php echo e($loop->index == 0 ? "active": ""); ?>"></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
        <div class="carousel-inner">
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="carousel-item <?php echo e($loop->index == 0 ? "active": ""); ?>">
                    <img src="/storage/<?php echo e($item->image); ?>" class="d-block w-100" alt="..." >
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>
    
    
    <section class="container my-4">
        <h1>Latest Reports</h1>
        <hr>
        <div class="row">
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="col-md-2 my-1">
                    <div class="card">
                        <img src="storage/<?php echo e($report->image); ?>" class="card-img-top" alt="<?php echo e($report->fullname); ?>" style="height: 200px;">
                        <div class="card-text card-body">
                            <b>Name:</b><br>
                            <?php echo e($report->fullname); ?>

                        </div>
                        <div class="card-footer">
                            <a href="<?php echo e(route('missing.details',$report->id)); ?>">
                                View details
                            </a>
                            <span class="fa-pull-right"><i class="fa fa-angle-right"></i></span>
                        </div>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</div>

<script src="<?php echo e(asset("js/jquery-3.3.1.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/bootstrap.bundle.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/datepicker.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/script.js")); ?>"></script>
</body>
</html>

<!-- todo:: About and contact -->