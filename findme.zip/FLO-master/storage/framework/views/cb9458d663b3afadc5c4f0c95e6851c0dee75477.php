<article class="col-md-3">
    <div class="card mb-3">
        <img src="/storage/<?php echo e($report->image); ?>" class="card-img-top" alt="<?php echo e($report->fullname); ?>" style="height: 200px;">
        <div class="card-body card-text">
            
            <div class="mb-1">
                <strong>Name: </strong><?php echo e($report->fullname); ?><br>
                <strong>Location:</strong> <?php echo e($report->place); ?>

            </div>
            
            <a href="<?php echo e(route('missing.details',$report->id)); ?>" class="btn btn-sm btn-success"> View details</a>
        </div>
    </div>
</article>