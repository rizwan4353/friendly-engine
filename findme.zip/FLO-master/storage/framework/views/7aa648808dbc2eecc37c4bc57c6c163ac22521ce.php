<?php $__env->startSection('content'); ?>
    <div class="col-8 mx-auto text-justify">
        
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Contact US</h3>
            </div>
            <div class="card-body">
                <form action="<?php echo e(route('inquiry.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="email" class="col-md-2 col-form-label">Email :</label>
                        <div class="col-md-10">
                            <input id="email" type="text" name="email"
                                   class="form-control <?php echo e($errors->has('email') ? "is-invalid" : ""); ?>" value="<?php echo e(old('email')); ?>"
                                   placeholder="Email">
                            <?php if($errors->has('email')): ?>
                                <strong class="invalid-feedback"><?php echo e($errors->first('email')); ?></strong>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="name" class="col-md-2 col-form-label">Name :</label>
                        <div class="col-md-10">
                            <input id="name" type="text" name="name"
                                   class="form-control <?php echo e($errors->has('name') ? "is-invalid" : ""); ?>" value="<?php echo e(old('name')); ?>"
                                   placeholder="Name">
                            <?php if($errors->has('name')): ?>
                                <strong class="invalid-feedback"><?php echo e($errors->first('name')); ?></strong>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="message" class="col-md-2 col-form-label">Message :</label>
                        <div class="col-md-10">
                        <textarea id="message" rows="7" name="message" class="form-control <?php echo e($errors->has('message') ?
                        "is-invalid" : ""); ?>" placeholder="Message"><?php echo e(old('message')); ?></textarea>
                            <?php if($errors->has('message')): ?>
                                <strong class="invalid-feedback"><?php echo e($errors->first('message')); ?></strong>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="offset-md-2">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                
                
                </form>
                <hr>
                <h4>For More Information:</h4>
                <h5>Mobile:
                    <small>03XX-XXXXXXX</small>
                </h5>
            
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>