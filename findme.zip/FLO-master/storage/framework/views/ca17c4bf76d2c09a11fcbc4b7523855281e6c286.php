<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="description" content="find your lost ones">
    <meta name="author" content="Muhammad Waqar">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.title', 'FLO') .' | '.  config('app.name')); ?></title>



    <link href="<?php echo e(asset('css/theme.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/fontawesome-all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/datepicker.min.css')); ?>" rel="stylesheet">

    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="<?php echo e(asset("css/style.css")); ?>">
</head>
<body>
<div id="app">
   
    <?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <main class="container-fluid py-4" id="main">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
</div>

<script src="<?php echo e(asset("js/jquery-3.3.1.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/bootstrap.bundle.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/notify.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/datepicker.min.js")); ?>"></script>
<script src="<?php echo e(asset("js/script.js")); ?>"></script>

<?php echo $__env->make('layouts.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
