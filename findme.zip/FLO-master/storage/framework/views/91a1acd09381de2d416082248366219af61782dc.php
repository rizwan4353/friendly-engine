<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
    
    
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <img src="<?php echo e(asset('favicon.ico')); ?>" alt="" height="30">
            <?php echo e(config('app.name')); ?>

        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>
        
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav m-auto">
                
                <li class="nav-item">
                    <a class="btn btn-success" href="<?php echo e(route('missing')); ?>">Missing People</a>
                </li>
                <li class="nav-item">
                    <a class="btn btn-success" href="<?php echo e(route('report.create')); ?>">Report</a>
                </li>
                <li class="nav-item">
                    <a class="btn btn-success" href="<?php echo e(route('about')); ?>">About</a>
                </li>
                <li class="nav-item">
                    <a class="btn btn-success" href="<?php echo e(route('contact')); ?>">Contact</a>
                </li>
                
            </ul>
            
            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                
                <?php if(auth()->guard('admin')->check()): ?>
                    <li class="nav-item">
                        <a class="btn btn-success" href="<?php echo e(route('admin')); ?>">Dashboard</a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item">
                        <a class="btn btn-success" href="<?php echo e(route('home')); ?>"><?php echo e(auth()->user()->fullname); ?></a>
                    </li>
                <?php endif; ?>
                <?php if(auth()->guard('admin')->guest()): ?>
                    
                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="btn btn-success" href="<?php echo e(route('login')); ?>">
                                <i class="fas fa-sign-in-alt"></i>
                                Login
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="btn btn-success" href="<?php echo e(route('admin.login')); ?>">
                                <i class="fas fa-user-lock"></i>
                                Admin
                            </a>
                        </li>
                    <?php endif; ?>
                
                <?php endif; ?>
                
            </ul>
        </div>
    

</nav>