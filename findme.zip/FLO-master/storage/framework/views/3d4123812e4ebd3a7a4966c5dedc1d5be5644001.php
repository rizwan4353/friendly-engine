<?php $__env->startSection('content'); ?>
    <?php if($reports->count()): ?>
        
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                <tr>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Report</th>
                    <th class="text-center">Actions</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($report->created_at->format('d-m-Y')); ?></td>
                        <td><?php echo e($report->fullname); ?></td>
                        <td><?php echo e($report->age); ?> years old</td>
                        <td><?php echo e($report->gender); ?></td>
                        <td><?php echo e($report->type); ?></td>
                        <td>
                            <div class="d-flex justify-content-around">
                                <form action="<?php echo e(route('report.completed',$report->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('patch'); ?>
                                    <button class="btn btn-sm btn-success">
                                        
                                        Complete
                                    </button>
                                </form>
                                <a class="btn btn-sm btn-info" href="<?php echo e(route('report.show',$report->id)); ?>">
                                    Details
                                </a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php else: ?>
        <div class="card col-4">
            <div class="card-body">
                <h5>Nothing to show yet.</h5>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("user.layout", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>