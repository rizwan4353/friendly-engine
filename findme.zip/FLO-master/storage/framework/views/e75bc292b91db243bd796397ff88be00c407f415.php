<?php $__env->startSection('content'); ?>
    <section class="text-center">
        <h2>Have you find or lost someone?</h2>
        <p>Please fill up give forms with valid information, to submit report.</p>
    </section>
    <form action="<?php echo e(route('report.store')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="col-10 m-auto">
            
            <div class="card mb-4">
                <div class="card-header">
                    <h4>Provide Your Information</h4>
                </div>
                <div class="card-body">
                    
                    <div class="form-group row">
                        <label for="reporter_first_name" class="col-md-3 col-form-label text-md-right">First Name* : </label>
                        <div class="col-md">
                            <input id="reporter_first_name" type="text"
                                   class="form-control<?php echo e($errors->has('reporter_first_name') ? ' is-invalid' : ''); ?>"
                                   name="reporter_first_name" value="<?php echo e(old('reporter_first_name')); ?>"
                                   placeholder="Enter First Name">
                            <?php if($errors->has('reporter_first_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('reporter_first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="lastName" class="col-md-3 col-form-label text-md-right">Last Name* : </label>
                        <div class="col-md">
                            <input id="lastName" type="text"
                                   class="form-control<?php echo e($errors->has('reporter_last_name') ? ' is-invalid' : ''); ?>"
                                   name="reporter_last_name" value="<?php echo e(old('reporter_last_name')); ?>"
                                   placeholder="Enter Last Name">
                            <?php if($errors->has('reporter_last_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('reporter_last_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="contact" class="col-md-3 col-form-label text-md-right">Mobile* : </label>
                        <div class="col-md">
                            <input id="contact" type="text"
                                   class="form-control<?php echo e($errors->has('contact') ? ' is-invalid' : ''); ?>"
                                   name="contact" value="<?php echo e(old('contact')); ?>"
                                   placeholder="Enter Your Mobile Number">
                            <?php if($errors->has('contact')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('contact')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="contact" class="col-md-3 col-form-label text-md-right">CNIC* : </label>
                        <div class="col-md">
                            <input id="contact" type="text"
                                   class="form-control<?php echo e($errors->has('cnic') ? ' is-invalid' : ''); ?>"
                                   name="cnic" value="<?php echo e(old('cnic')); ?>"
                                   placeholder="Enter Your CNIC Number">
                            <?php if($errors->has('cnic')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('cnic')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="address" class="col-md-3 col-form-label text-md-right">Address* : </label>
                        <div class="col-md">
                            <input id="address" type="text"
                                   class="form-control<?php echo e($errors->has('address') ? ' is-invalid' : ''); ?>"
                                   name="address" value="<?php echo e(old('address')); ?>"
                                   placeholder="Enter address">
                            <?php if($errors->has('address')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('address')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h4>Enter Details of Missing Person</h4>
                </div>
                <div class="card-body">
                    
                    <div class="form-group row">
                        <label for="type" class="col-md-3 form-check-label text-md-right">Report Type : </label>
                        <div class="col-md " id="type">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="lost" name="type" value="lost" class="custom-control-input" checked>
                                <label class="custom-control-label" for="lost">Lost</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="found" name="type" value="found" class="custom-control-input">
                                <label class="custom-control-label" for="found">Found</label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="firstName" class="col-md-3 col-form-label text-md-right">First Name : </label>
                        <div class="col-md">
                            <input id="firstName" type="text"
                                   class="form-control<?php echo e($errors->has('first_name') ? ' is-invalid' : ''); ?>"
                                   name="first_name" value="<?php echo e(old('first_name')); ?>"
                                   placeholder="Enter First Name">
                            <small class="form-text text-muted">
                                It's Optional in case you don't know the name
                            </small>
                            <?php if($errors->has('first_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('first_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="lastName" class="col-md-3 col-form-label text-md-right">Last Name : </label>
                        <div class="col-md">
                            <input id="lastName" type="text"
                                   class="form-control<?php echo e($errors->has('last_name') ? ' is-invalid' : ''); ?>"
                                   name="last_name" value="<?php echo e(old('last_name')); ?>"
                                   placeholder="Enter Last Name">
                            <small class="form-text text-muted">
                                It's Optional in case you don't know the name
                            </small>
                            <?php if($errors->has('last_name')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('last_name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="age" class="col-md-3 col-form-label text-md-right">Age : </label>
                        <div class="col-md-3">
                            <input id="age" type="text"
                                   class="form-control<?php echo e($errors->has('age') ? ' is-invalid' : ''); ?>"
                                   name="age" value="<?php echo e(old('age')); ?>"
                                   placeholder="Enter age">
                            <?php if($errors->has('age')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('age')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
    
                    <div class="form-group row">
                        <label for="missing" class="col-md-3 col-form-label text-md-right">Date missing : </label>
                        <div class="col-md-3">
                            <input id="missing" type="text" date-pick="true"
                                   class="form-control<?php echo e($errors->has('missing_at') ? ' is-invalid' : ''); ?>"
                                   name="missing_at" value="<?php echo e(old('missing_at')); ?>"
                                   placeholder="Date missing" autocomplete="off">
                            <?php if($errors->has('missing_at')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('missing_at')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="gender" class="col-md-3 form-check-label text-md-right">Gender : </label>
                        <div class="col-md " id="gender">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="male" name="gender" value="male" class="custom-control-input" checked>
                                <label class="custom-control-label" for="male">Male</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="female" name="gender" value="female" class="custom-control-input">
                                <label class="custom-control-label" for="female">Female</label>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="age" class="col-md-3 col-form-label text-md-right">Place : </label>
                        <div class="col-md">
                            <input id="age" type="text"
                                   class="form-control<?php echo e($errors->has('place') ? ' is-invalid' : ''); ?>"
                                   name="place" value="<?php echo e(old('place')); ?>"
                                   placeholder="Place where found or lost">
                            <?php if($errors->has('place')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('place')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <label for="description" class="col-md-3 col-form-label text-right">Description : </label>
                        <div class="col-md">
                                <textarea id="description" name="description"
                                          class="form-control<?php echo e($errors->has('description') ? ' is-invalid' : ''); ?>"
                                          placeholder="Describe the appearance and details"
                                          rows="4"><?php echo e(old('description')); ?></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('description')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group row">
                        <h5 class="col-md-3 col-form-label text-right">Image :</h5>
                        <div class="col-md">
                            <div class="custom-file">
                                <input id="image" type="file" name="image"
                                       class="custom-file-input<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>"
                                       value="<?php echo e(old('image')); ?>" placeholder="Enter image">
                                <label class="custom-file-label" for="image">Choose file</label>
                            </div>
                            <small class="form-text text-muted">This is most important one.</small>
                            <?php if($errors->has('image')): ?>
                                <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($errors->first('image')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-primary  fa-pull-right">Submit</button>
                    </div>
                
                </div>
            </div>
        
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>