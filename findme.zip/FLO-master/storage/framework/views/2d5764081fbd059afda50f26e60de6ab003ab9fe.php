<?php $__env->startSection('content'); ?>
    <div class="row mb-4">
        
        <div class="col-md-4">
            <div class="card text-white bg-primary">
                <div class="card-body">
                    <span class="card-body-icon">
                        <i class="fa fa-user"></i>
                    </span>
                    <h5 class="card-title"><?php echo e($members); ?> Members</h5>
                </div>
                <div class="card-footer">
                    <a class="text-white" href="<?php echo e(route('admin.user.list')); ?>">See now</a>
                    <span class="fa-pull-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </div>
            </div>
        </div>
    
        <div class="col-md-4">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <span class="card-body-icon">
                        <i class="far fa-list-alt"></i>
                    </span>
                    <h5 class="card-title"><?php echo e($reports); ?> Reports</h5>
                </div>
                <div class="card-footer">
                    <a class="text-white" href="<?php echo e(route('admin.reports')); ?>">See now</a>
                    <span class="fa-pull-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card text-white bg-danger">
                <div class="card-body">
                    <span class="card-body-icon">
                        <i class="fa fa-question"></i>
                    </span>
                    <h5 class="card-title"><?php echo e($inquiries); ?> Inquiries</h5>
                </div>
                <div class="card-footer">
                    <a class="text-white" href="<?php echo e(route('inquiry.index')); ?>">See now</a>
                    <span class="fa-pull-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </div>
            </div>
        </div>
    
    </div>
    <?php if($logs->count()): ?>
        <h2 class="text-center">Activities</h2>
        <section class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                <tr>
                    <th>Time</th>
                    <th>Member</th>
                    <th>Description</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                        <td><a href="<?php echo e(route('admin.user.show',$log->user->id)); ?>"><?php echo e($log->user->fullname); ?></a></td>
                        <td><?php echo e($log->description); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </section>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>