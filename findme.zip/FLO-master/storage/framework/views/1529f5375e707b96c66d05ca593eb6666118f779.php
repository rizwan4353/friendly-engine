<?php if(session('message')): ?>
    <script>
        notify("<?php echo e(session('message')); ?>");
    </script>
<?php endif; ?>