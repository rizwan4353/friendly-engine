<?php $__env->startSection('content'); ?>
    <h2>Cases Completed</h2>
    
    <?php if($reports->count()): ?>
        
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                <tr>
                    <th>Action</th>
                    <th>Date</th>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Report</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <form action="<?php echo e(route('report.destroy',$report->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <button class="btn btn-sm btn-danger">
                                    <i class="fas fa-trash-alt"></i>
                                    Delete
                                </button>
                            </form>
                        </td>
                        <td><?php echo e($report->created_at->format('d-m-Y')); ?></td>
                        <td><a href="<?php echo e(route('report.show',$report->id)); ?>"><?php echo e($report->fullname); ?></a></td>
                        <td><?php echo e($report->age); ?> years old</td>
                        <td><?php echo e($report->gender); ?></td>
                        <td><?php echo e($report->type); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    <?php else: ?>
        <div class="card col-4">
            <div class="card-body">
                <h5>Nothing to show yet.</h5>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("user.layout", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>