<?php $__env->startSection('content'); ?>
    
    <section class="table-responsive">
        <table class="table table-striped table-hover">
            <thead class="thead-dark">
            <tr>
                <th>Date Joined</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Contact</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                    <td><?php echo e($user->fullname); ?></td>
                    <td><?php echo e($user->gender); ?></td>
                    <td><?php echo e($user->contact); ?>

                    </td>
                    <td>
                        <a class="btn btn-secondary btn-sm" href="<?php echo e(route('admin.user.show',$user->id)); ?>">view details</a>
                        <button class="btn btn-sm btn-danger"
                                data-toggle="modal" data-target="#user-<?php echo e($user->id); ?>" >Remove</button>
                    </td>
                </tr>

                <div class="modal fade" id="user-<?php echo e($user->id); ?>" tabindex="-1" role="dialog"
                     aria-labelledby="Confirm to delete" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title text-danger">Warning</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>This will permanently delete Member, are you sure you want to delete it</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                
                                <form action="<?php echo e(route('admin.user.destroy', $user->id)); ?>" method="post">
                                    <?php echo e(method_field('delete')); ?>

                                    <?php echo e(csrf_field()); ?>

                                    <button type="submit" class="btn btn-danger"
                                            data-toggle="tooltip" title="Delete Permanently" data-placement="bottom">
                                        Confirm
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>