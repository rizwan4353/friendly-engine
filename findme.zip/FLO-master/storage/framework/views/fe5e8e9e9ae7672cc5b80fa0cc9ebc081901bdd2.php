<?php $__env->startSection('content'); ?>
    
    <div class="row mb-4">
        
        <div class="col-md-4">
            <div class="card text-white bg-info">
                <div class="card-body">
                    <span class="card-body-icon">
                        <i class="fa fa-list"></i>
                    </span>
                    <h5 class="card-title"><?php echo e($report->pending()->count()); ?> Reports Pending</h5>
                </div>
                <div class="card-footer">
                    <a class="text-white" href="<?php echo e(route('report.pending')); ?>">See now</a>
                    <span class="fa-pull-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card text-white bg-warning">
                <div class="card-body">
                    <span class="card-body-icon">
                        <i class="fa fa-sync-alt"></i>
                    </span>
                    <h5 class="card-title"><?php echo e($report->status('processing')->count()); ?> Reports In Progress</h5>
                </div>
                <div class="card-footer">
                    <a class="text-white" href="<?php echo e(route('report.processing')); ?>">See now</a>
                    <span class="fa-pull-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card text-white bg-danger">
                <div class="card-body">
                    <span class="card-body-icon">
                        <i class="fa fa-archive"></i>
                    </span>
                    <h5 class="card-title"><?php echo e($report->status('archived')->count()); ?> Cases Completed</h5>
                </div>
                <div class="card-footer">
                    <a class="text-white" href="<?php echo e(route('report.archived')); ?>">See now</a>
                    <span class="fa-pull-right">
                        <i class="fa fa-angle-right"></i>
                    </span>
                </div>
            </div>
        </div>
        
    </div>

    <h2 class="text-center">Activities Log</h2>
    <section class="table-responsive">
        <table class="table">
            <thead class="thead-light">
            <tr>
                <th>Time</th>
                <th>Description</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = auth()->user()->activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($log->created_at->diffForHumans()); ?></td>
                    <td><?php echo e($log->description); ?></td>
                </tr>
                

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>