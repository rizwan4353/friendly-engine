<?php $__env->startSection('content'); ?>
    <h2 class="text-center">Contact : <?php echo e($report->reporter->contact); ?></h2>
    <article class="col-10 mx-auto">
        <div class="card card-300 mb-3">
            <section class="card-img">
                <img src="/storage/<?php echo e($report->image); ?>" class="card-img-top" alt="<?php echo e($report->fullname); ?>">
            </section>
            <div class="card-body">
                <h2 class="card-title"><?php echo e($report->type); ?></h2>
                <div class="card-text">
                    <h5>Name: <?php echo e($report->fullname); ?></h5>
                    <h5>Age: <?php echo e($report->age); ?> years</h5>
                    <h5>Gender: <?php echo e($report->gender); ?></h5>
                    <h5>Location: <?php echo e($report->place); ?></h5>
                    <h5>Description:</h5>
                    <p class="text-justify"><?php echo e($report->description); ?></p>
                </div>
            </div>
        </div>
    </article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>