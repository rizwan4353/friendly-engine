<?php $__env->startSection('content'); ?>
    
    <article class="col-10 mx-auto">
        <div class="card card-300 mb-3">
            <section class="card-img">
                <img src="/storage/<?php echo e($report->image); ?>" class="card-img-top" alt="<?php echo e($report->fullname); ?>">
            </section>
            <div class="card-body">
                <h2 class="card-title"><b>Missing</b></h2>
                <div class="card-text">
                    <h5>
                       <b> Name: </b><?php echo e($report->fullname); ?>

                    </h5>
                    <h5>
                        <b>Age: </b><?php echo e($report->age); ?> years
                    </h5>
                    <h5>
                       <b> Gender: </b><?php echo e($report->gender); ?>

                    </h5>
                    <h5>
                        <b>Location: </b><?php echo e($report->place); ?>

                    </h5>
                    <h5>
                        <b>Type of Report: </b><?php echo e($report->type); ?>

                    </h5>
                    <h5>
                    <b>Description:</b>
                    </h5>
                    <p class="text-justify"><?php echo e($report->description); ?></p>
                </div>
            </div>
        </div>
    </article>
    
    <article class="col-10 mx-auto">
        <div class="card">
            <div class="card-header"><h4 class="card-title">Reporter's Details </h4></div>
            <div class="card-body">
                
                <p>
                    <b>Name: </b> <?php echo e($report->reporter->fullname); ?>

                </p>
                <p>
                    <b>Contact: </b> <?php echo e($report->reporter->contact); ?>

                </p>
                <p>
                    <b>CNIC: </b> <?php echo e($report->reporter->cnic); ?>

                </p>
                <p>
                    <b>Address: </b> <?php echo e($report->reporter->address); ?>

                </p>
                
            </div>
        
        </div>
    </article>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("user.layout", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>