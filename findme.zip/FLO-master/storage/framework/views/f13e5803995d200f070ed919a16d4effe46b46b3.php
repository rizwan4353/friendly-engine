<nav class="navbar navbar-expand navbar-dark bg-primary static-top">
    
    <a class="navbar-brand mr-1" href="<?php echo e(route('index')); ?>">
        <img src="<?php echo e(asset('favicon.ico')); ?>" alt="" height="30">
    
        <?php echo e(config('app.name')); ?>

    </a>
    
    <button class="btn btn-link btn-sm text-light order-1 order-sm-0" id="sidebarToggle" >
        <i class="fas fa-bars"></i>
    </button>
    
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            
            <a class="btn btn-sm btn-danger my-2 my-sm-0" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();document.getElementById('logout-form').submit();">
                <i class="fa fa-sign-out-alt"></i>
                <?php echo e(__('Logout')); ?>

            </a>
            
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        
        </li>
    </ul>

</nav>
