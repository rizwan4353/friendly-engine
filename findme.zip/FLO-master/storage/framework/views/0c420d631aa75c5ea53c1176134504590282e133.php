<?php $__env->startSection('content'); ?>
    <div class="card card-login mx-auto mt-5">
        
        <div class="card-header">
            <h3 class="text-center">Admin</h3>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('admin.login')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <div class="form-label-group">
                        <input id="inputEmail" type="email"
                               class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email"
                               value="<?php echo e(old('email')); ?>" placeholder="Email address" required autofocus>
                        <label for="inputEmail">Email address</label>
                    </div>
                    <?php if($errors->has('email')): ?>
                        <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="form-label-group">
                        <input id="inputPassword" type="password"
                               class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password"
                               placeholder="Password" required>
                        <label for="inputPassword">Password</label>
                    </div>
                    <?php if($errors->has('password')): ?>
                        <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                    <?php endif; ?>
                </div>
                <div class="form-group">
                    <div class="checkbox">
                        <label>
                            <input type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                            Remember Password
                        </label>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Login</button>
                
            </form>
            <div class="text-center">
                
                <a class="d-block small mt-3" href="<?php echo e(route('password.request')); ?>"> Forgot Your Password?</a>
            
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>