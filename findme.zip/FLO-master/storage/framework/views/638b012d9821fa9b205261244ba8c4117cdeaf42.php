<?php $__env->startSection('content'); ?>
    
    <section class="container">
        <form action="">
            <div class="form-group form-row">
                
                <div class="col-md-10 col-9">
                    <input id="search" type="text" name="search"
                           class="form-control" value="<?php echo e(old('search')); ?>" placeholder="Search">
                </div>
                <button type="submit" class="col-md-2 col-3 btn btn-success">Search</button>
            </div>
        </form>
        
        <div class="row">
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('report.card', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <?php echo $__env->make('layouts.paginate', ['paginator' => $reports], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>